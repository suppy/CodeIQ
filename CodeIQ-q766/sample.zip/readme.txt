hello.pm6/Perl 6
hello.cpp/C++11
hello.node.js/Node.js

5行目以降には、感想や工夫した点などをお書き下さい。
1〜3行目の、ファイル名と言語名のペアは、スラッシュ( / ) で区切って下さい。
言語名は、ideone の表記に従って下さい。