CodeIQ-q766.rb/Ruby
CodeIQ-q766.py/Python
CodeIQ-q766.js/JavaScript

hello, worldを使わないようにしようと考えましたが、逆に文字が増えてしまったので、断念しました。
全然工夫ができなくて残念です。
さすがに☆３つは手が出ません。
